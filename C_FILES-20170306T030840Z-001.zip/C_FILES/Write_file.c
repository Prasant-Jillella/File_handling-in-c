#include<stdio.h>
#include<stdlib.h>
int main()
{
  FILE * fp;
  fp = fopen("Prasant.txt","w");
  fprintf(fp,"I am PRASANT \nThe Greatest Programmer in the world");
  fclose(fp);
}
