#include<stdio.h>
int main()
{
    int i;
    FILE * fp,fp1;
    fp=fopen("Prasant.txt","w+");
    fprintf(fp,"I am good");
    char f[100];
    fscanf(fp,"%s",&f);
    fprintf("%s",f);
    fclose(fp);
    scanf("%d",&i);
}
