#include<stdio.h>
int main()
{
  FILE * fp;
  fp = fopen("Prasant.txt","a"); 
  fprintf(fp,"\nI will rise to the challenges of my life and win!!");
  fclose(fp);
}
