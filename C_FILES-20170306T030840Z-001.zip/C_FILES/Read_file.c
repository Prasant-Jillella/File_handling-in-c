#include<stdio.h>
int main()
{
  int i;
  FILE * fp;
  fp = fopen("Prasant.txt","r");
  char f[100];
  while(!feof(fp))
  {
    fgets(f,100,fp);
    puts(f);
  }
  fclose(fp);
  scanf("%d",&i);
}
